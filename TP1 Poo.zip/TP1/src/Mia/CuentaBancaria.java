package Mia;

public class CuentaBancaria {

    private double saldo;

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getSaldo() {
        return saldo;
    }

    public double obtenerSaldoOriginal() {
        return saldo;
    }
}