package Mia;

public class Jugador {

    private String nombre;
    private int nivel;
    private int puntos;

    // Constructor
    public Jugador(String nombre) {
        this.nombre = nombre;
        this.nivel = 1;
        this.puntos = 0;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public int getPuntos() {
        return puntos;
    }

    // Sumar puntos
    public void ganarPuntos(int cantidad) {
        if (cantidad > 0) {
            puntos += cantidad;
        } else {
            System.out.println("La cantidad debe ser positiva.");
        }
    }

    // Subir nivel
    public void subirNivel() {
        nivel++;
    }
}