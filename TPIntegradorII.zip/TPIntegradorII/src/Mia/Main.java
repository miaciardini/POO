package Mia;

public class Main {

    public static void main(String[] args) {

        // EJERCICIO 1: JUGADORES

        System.out.println("=== JUGADORES ===");

        Jugador j1 = new Jugador("Mia");
        Jugador j2 = new Jugador("Oli");

        // Mostrar datos iniciales
        System.out.println("Jugador 1: " + j1.getNombre());
        System.out.println("Nivel: " + j1.getNivel());
        System.out.println("Puntos: " + j1.getPuntos());

        System.out.println();

        System.out.println("Jugador 2: " + j2.getNombre());
        System.out.println("Nivel: " + j2.getNivel());
        System.out.println("Puntos: " + j2.getPuntos());

        // Sumar puntos
        j1.ganarPuntos(100);
        j2.ganarPuntos(50);

        // Intentar sumar cantidad negativa
        j1.ganarPuntos(-20);

        // Subir nivel del primer jugador
        j1.subirNivel();

        // Mostrar resultados finales
        System.out.println("\n=== RESULTADOS FINALES ===");

        System.out.println(j1.getNombre());
        System.out.println("Nivel: " + j1.getNivel());
        System.out.println("Puntos: " + j1.getPuntos());

        System.out.println();

        System.out.println(j2.getNombre());
        System.out.println("Nivel: " + j2.getNivel());
        System.out.println("Puntos: " + j2.getPuntos());


        // EJERCICIO 2: PERSONAS

        System.out.println("\n=== PERSONAS ===");

        Docente d1 = new Docente("Laura", 35, "Matematica");
        Preceptor p1 = new Preceptor("Carlos", 40, "5to A");

        // Mostrar información
        System.out.println("\nDOCENTE");
        d1.mostrarInformacion();

        System.out.println("\nPRECEPTOR");
        p1.mostrarInformacion();

        // Modificar edad del docente
        d1.setEdad(36);

        System.out.println("\n=== DOCENTE CON EDAD MODIFICADA ===");
        d1.mostrarInformacion();
    }
}