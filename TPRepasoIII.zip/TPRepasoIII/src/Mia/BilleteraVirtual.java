package Mia;

public class BilleteraVirtual extends MedioPago {

    private String nombreAplicacion;

    // Constructor
    public BilleteraVirtual(String titular, String nombreAplicacion) {
        super(titular);
        this.nombreAplicacion = nombreAplicacion;
    }

    // Getter
    public String getNombreAplicacion() {
        return nombreAplicacion;
    }

    // Sobrescritura
    @Override
    public void procesarPago(double monto) {

        if (monto > 0) {
            System.out.println("Tipo de pago: Billetera virtual");
            System.out.println("Titular: " + getTitular());
            System.out.println("Aplicacion: " + nombreAplicacion);
            System.out.println("Pago procesado por $" + monto);
        } else {
            System.out.println("El monto debe ser mayor que cero.");
        }
    }
}