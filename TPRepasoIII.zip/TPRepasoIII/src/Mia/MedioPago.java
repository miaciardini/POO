package Mia;

public class MedioPago {

    private String titular;

    // Constructor
    public MedioPago(String titular) {
        this.titular = titular;
    }

    // Getter
    public String getTitular() {
        return titular;
    }

    // Método original
    public void procesarPago(double monto) {
        if (monto > 0) {
            System.out.println("Procesando pago por $" + monto);
        } else {
            System.out.println("El monto debe ser mayor que cero.");
        }
    }
}