package Mia;

public class MaterialDigital {

    private String titulo;

    // Constructor
    public MaterialDigital(String titulo) {
        this.titulo = titulo;
    }

    // Getter
    public String getTitulo() {
        return titulo;
    }

    // Método original
    public void mostrarDescripcion() {
        System.out.println("Material disponible en la biblioteca digital");
    }
}