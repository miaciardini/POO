package Mia;

public class Main {

    public static void main(String[] args) {

        // EJERCICIO 1: MATERIAL DIGITAL

        System.out.println("=== MATERIAL DIGITAL ===");

        LibroDigital libro = new LibroDigital("Harry Potter");
        Audiolibro audio = new Audiolibro("El Principito");

        libro.mostrarDescripcion();

        System.out.println();

        audio.mostrarDescripcion();


        // EJERCICIO 2: MEDIOS DE PAGO

        System.out.println("\n=== MEDIOS DE PAGO ===");

        Tarjeta tarjeta = new Tarjeta("Mia", "1234");

        BilleteraVirtual billetera =
                new BilleteraVirtual("Oli", "Mercado Pago");

        // Procesar pagos
        tarjeta.procesarPago(15000);

        System.out.println();

        billetera.procesarPago(8500);

        // Intentar realizar un pago con monto negativo
        System.out.println("\n=== VALIDACION ===");

        tarjeta.procesarPago(-500);
    }
}