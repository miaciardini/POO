package Mia;

public class Tarjeta extends MedioPago {

    private String ultimosCuatroDigitos;

    // Constructor
    public Tarjeta(String titular, String ultimosCuatroDigitos) {
        super(titular);
        this.ultimosCuatroDigitos = ultimosCuatroDigitos;
    }

    // Getter
    public String getUltimosCuatroDigitos() {
        return ultimosCuatroDigitos;
    }

    // Sobrescritura
    @Override
    public void procesarPago(double monto) {

        if (monto > 0) {
            System.out.println("Tipo de pago: Tarjeta");
            System.out.println("Titular: " + getTitular());
            System.out.println("Tarjeta terminada en: " + ultimosCuatroDigitos);
            System.out.println("Pago procesado por $" + monto);
        } else {
            System.out.println("El monto debe ser mayor que cero.");
        }
    }
}